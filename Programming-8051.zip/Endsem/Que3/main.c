#include <at89c5131.h>
#include "endsem.h"


char S_str[6]= {0,0,0,0,0,0};   //String for Balance Sita
char G_str[6] = {0,0,0,0,0,0};  //String for Balance Gita
char n500_s[3]= {0,0,0};    // STRING FOR 500RS NOTE
char n100_s[3]= {0,0,0};    // STRING FOR 100RS NOTE

char password[5] = {0,0,0,0,0} ;   //PASSWORD ARRAY
//Main function

//-------------------------------------------------
void main(void)
{
	unsigned char ch=0;
	unsigned char ch1=0;
	unsigned char ch2=0;
	unsigned char ch3=0;
	
	uart_init();	// Please finish this function in endsem.h 
	
    while (1)
    {
			transmit_string("Press A for Account display and W for withdrawing cash\r\n");
        //Receive a character
			ch = receive_char();
		
			//Decide which test function to run based on character sent
      //Displays the string on the terminal software
			switch(ch)
			{
				case 'A'://lcd_test();
								 transmit_string("Hello, Please enter Account Number\r\n");
								 ch1 = receive_char();
								 transmit_string("Please enter password\r\n");
								 password[4] = receive_char();
								 password[3] = receive_char();
								password[2] = receive_char();
								password[1] = receive_char();
								password[0] = receive_char();
								
				
								 switch(ch1){
									 case '1':if(password[4] == 'E' && password[3] == 'E' && password[2] == '3' && password[1] == '3' && password[0] == '7'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														}
														
														break;
									 
									 case '2':if(password[4] == 'U' && password[3] == 'P' && password[2] == 'L' && password[1] =='A' && password[0] == 'B'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														}
														break;
									 
									 default:transmit_string("No such account, please enter valid details\r\n");
								 break;
								 }
								 break;
				
				case 'a'://lcd_test();
								 transmit_string("Hello, Please enter Account Number\r\n");
								 ch1 = receive_char();
								 switch(ch1){
									 case '1':if(password[4] == 'E' && password[3] == 'E' && password[2] == '3' && password[1] == '3' && password[0] == '7'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														}
														break;
									 
									 case '2':if(password[4] == 'U' && password[3] == 'P' && password[2] == 'L' && password[1] == 'A' && password[0] == 'B'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														}
														break;
									 
									 default:transmit_string("No such account, please enter valid details\r\n");
								 break;
								 }
								 break;
				
				case 'W'://led_test();
								 transmit_string("Withdraw state, enter account number\r\n");
								 ch1 = receive_char();
								 
								 switch(ch1){
									 case '1':if(password[4] == 'E' && password[3] == 'E' && password[2] == '3' && password[1] == '3' && password[0] == '7'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														transmit_string("Enter Amount, in hundreds\r\n");
														ch2 = receive_char();
														ch3 = receive_char();
									 
														transmit_string("Remaining Balance: ZZZZ\r\n");
														transmit_string("500 Notes: ");
														
															int_to_string_2(0, n500_s);
															transmit_string(n500_s);
															transmit_string(", 100 Notes: ");
														  transmit_char(ch2);
															transmit_char(ch3);
															transmit_string("\r\n");
														}
														
														
														break;
									 
									 case '2':if(password[4] == 'U' && password[3] == 'P' && password[2] == 'L' && password[1] == 'A' && password[0] == 'B'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														transmit_string("Enter Amount, in hundreds\r\n");
														ch2 = receive_char();
														ch3 = receive_char();
									 
														transmit_string("Remaining Balance: ZZZZ\r\n");
														transmit_string("500 Notes: ");
														
															int_to_string_2(0, n500_s);
															transmit_string(n500_s);
															transmit_string(", 100 Notes: ");
														  transmit_char(ch2);
															transmit_char(ch3);
															transmit_string("\r\n");
														}
														
															
														break;
									 
									 default:transmit_string("No such account, please enter valid details\r\n");
								 break;
								 }
								 break;
				
				case 'w'://led_test();
								 transmit_string("Withdraw state, enter account number\r\n");
								 ch1 = receive_char();
								 
								 switch(ch1){
									 case '1':if(password[4] == 'E' && password[3] == 'E' && password[2] == '3' && password[1] == '3' && password[0] == '7'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														transmit_string("Enter Amount, in hundreds\r\n");
														ch2 = receive_char();
														ch3 = receive_char();
									 
														transmit_string("Remaining Balance: ZZZZ\r\n");
														transmit_string("500 Notes: ");
														
															int_to_string_2(0, n500_s);
															transmit_string(n500_s);
															transmit_string(", 100 Notes: ");
														  transmit_char(ch2);
															transmit_char(ch3);
															transmit_string("\r\n");
														}
														
														
														break;
									 
									 case '2':if(password[4] == 'U' && password[3] == 'P' && password[2] == 'L' && password[1] == 'A' && password[0] == 'B'){
														transmit_string("Account Holder: Sita\r\n");
														transmit_string("Account Balance: 10000\r\n");
														transmit_string("Enter Amount, in hundreds\r\n");
														ch2 = receive_char();
														ch3 = receive_char();
									 
														transmit_string("Remaining Balance: ZZZZ\r\n");
														transmit_string("500 Notes: ");
														
															int_to_string_2(0, n500_s);
															transmit_string(n500_s);
															transmit_string(", 100 Notes: ");
														  transmit_char(ch2);
															transmit_char(ch3);
															transmit_string("\r\n");
														}
														break;
									 
									 default:transmit_string("No such account, please enter valid details\r\n");
								 break;
								 }
								 break;
							
				default:transmit_string("Incorrect test. Pass correct number\r\n");
								 break;
				
			}
			
    }
}


